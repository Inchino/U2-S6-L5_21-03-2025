﻿namespace GestionaleHotel.ViewModels
{
    public class CameraDetailViewModel
    {
        public int CameraId { get; set; }
        public string Numero { get; set; }
        public string Tipo { get; set; }
        public decimal Prezzo { get; set; }
        public bool Disponibile { get; set; }
    }
}
