﻿namespace GestionaleHotel.ViewModels
{
    public class ClienteListViewModel
    {
        public int ClienteId { get; set; }
        public string NomeCompleto { get; set; }
        public string Email { get; set; }
        public string Telefono { get; set; }
    }
}
